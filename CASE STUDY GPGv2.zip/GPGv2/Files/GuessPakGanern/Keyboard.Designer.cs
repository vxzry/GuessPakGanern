﻿namespace GuessPakGanern
{
    partial class Keyboard
    {
        /// <summary> 
        /// Required designer variable.
        /// </summary>
        private System.ComponentModel.IContainer components = null;

        /// <summary> 
        /// Clean up any resources being used.
        /// </summary>
        /// <param name="disposing">true if managed resources should be disposed; otherwise, false.</param>
        protected override void Dispose(bool disposing)
        {
            if (disposing && (components != null))
            {
                components.Dispose();
            }
            base.Dispose(disposing);
        }

        #region Component Designer generated code

        /// <summary> 
        /// Required method for Designer support - do not modify 
        /// the contents of this method with the code editor.
        /// </summary>
        private void InitializeComponent()
        {
            System.ComponentModel.ComponentResourceManager resources = new System.ComponentModel.ComponentResourceManager(typeof(Keyboard));
            this.key23 = new GuessPakGanern.Key();
            this.key13 = new GuessPakGanern.Key();
            this.key16 = new GuessPakGanern.Key();
            this.key17 = new GuessPakGanern.Key();
            this.key26 = new GuessPakGanern.Key();
            this.key18 = new GuessPakGanern.Key();
            this.key25 = new GuessPakGanern.Key();
            this.key19 = new GuessPakGanern.Key();
            this.key15 = new GuessPakGanern.Key();
            this.key20 = new GuessPakGanern.Key();
            this.key14 = new GuessPakGanern.Key();
            this.key21 = new GuessPakGanern.Key();
            this.key22 = new GuessPakGanern.Key();
            this.key12 = new GuessPakGanern.Key();
            this.key11 = new GuessPakGanern.Key();
            this.key24 = new GuessPakGanern.Key();
            this.key10 = new GuessPakGanern.Key();
            this.key9 = new GuessPakGanern.Key();
            this.key8 = new GuessPakGanern.Key();
            this.key7 = new GuessPakGanern.Key();
            this.key6 = new GuessPakGanern.Key();
            this.key5 = new GuessPakGanern.Key();
            this.key4 = new GuessPakGanern.Key();
            this.key3 = new GuessPakGanern.Key();
            this.key2 = new GuessPakGanern.Key();
            this.key1 = new GuessPakGanern.Key();
            this.SuspendLayout();
            // 
            // key23
            // 
            this.key23.Anchor = ((System.Windows.Forms.AnchorStyles)((System.Windows.Forms.AnchorStyles.Bottom | System.Windows.Forms.AnchorStyles.Right)));
            this.key23.BackColor = System.Drawing.Color.Transparent;
            this.key23.BackgroundImage = ((System.Drawing.Image)(resources.GetObject("key23.BackgroundImage")));
            this.key23.BackgroundImageLayout = System.Windows.Forms.ImageLayout.Zoom;
            this.key23.Cursor = System.Windows.Forms.Cursors.Hand;
            this.key23.FlatAppearance.BorderSize = 0;
            this.key23.FlatAppearance.CheckedBackColor = System.Drawing.Color.Transparent;
            this.key23.FlatAppearance.MouseDownBackColor = System.Drawing.Color.Transparent;
            this.key23.FlatAppearance.MouseOverBackColor = System.Drawing.Color.Transparent;
            this.key23.FlatStyle = System.Windows.Forms.FlatStyle.System;
            this.key23.Font = new System.Drawing.Font("Tw Cen MT", 26.25F, System.Drawing.FontStyle.Bold);
            this.key23.ForeColor = System.Drawing.Color.Black;
            this.key23.ImeMode = System.Windows.Forms.ImeMode.NoControl;
            this.key23.Location = new System.Drawing.Point(70, 15);
            this.key23.Name = "key23";
            this.key23.Size = new System.Drawing.Size(38, 50);
            this.key23.TabIndex = 1;
            this.key23.Text = "A";
            this.key23.UseVisualStyleBackColor = false;
            this.key23.MouseClick += new System.Windows.Forms.MouseEventHandler(this.key13_MouseClick);
            // 
            // key13
            // 
            this.key13.Anchor = ((System.Windows.Forms.AnchorStyles)((System.Windows.Forms.AnchorStyles.Bottom | System.Windows.Forms.AnchorStyles.Right)));
            this.key13.BackColor = System.Drawing.Color.Transparent;
            this.key13.BackgroundImage = ((System.Drawing.Image)(resources.GetObject("key13.BackgroundImage")));
            this.key13.BackgroundImageLayout = System.Windows.Forms.ImageLayout.Zoom;
            this.key13.Cursor = System.Windows.Forms.Cursors.Hand;
            this.key13.FlatAppearance.BorderSize = 0;
            this.key13.FlatAppearance.CheckedBackColor = System.Drawing.Color.Transparent;
            this.key13.FlatAppearance.MouseDownBackColor = System.Drawing.Color.Transparent;
            this.key13.FlatAppearance.MouseOverBackColor = System.Drawing.Color.Transparent;
            this.key13.FlatStyle = System.Windows.Forms.FlatStyle.System;
            this.key13.Font = new System.Drawing.Font("Tw Cen MT", 26.25F, System.Drawing.FontStyle.Bold);
            this.key13.ForeColor = System.Drawing.Color.Gainsboro;
            this.key13.ImeMode = System.Windows.Forms.ImeMode.NoControl;
            this.key13.Location = new System.Drawing.Point(357, 123);
            this.key13.Name = "key13";
            this.key13.Size = new System.Drawing.Size(38, 50);
            this.key13.TabIndex = 25;
            this.key13.Text = "A";
            this.key13.UseVisualStyleBackColor = false;
            this.key13.MouseClick += new System.Windows.Forms.MouseEventHandler(this.key13_MouseClick);
            // 
            // key16
            // 
            this.key16.Anchor = ((System.Windows.Forms.AnchorStyles)((System.Windows.Forms.AnchorStyles.Bottom | System.Windows.Forms.AnchorStyles.Right)));
            this.key16.BackColor = System.Drawing.Color.Transparent;
            this.key16.BackgroundImage = ((System.Drawing.Image)(resources.GetObject("key16.BackgroundImage")));
            this.key16.BackgroundImageLayout = System.Windows.Forms.ImageLayout.Zoom;
            this.key16.Cursor = System.Windows.Forms.Cursors.Hand;
            this.key16.FlatAppearance.BorderSize = 0;
            this.key16.FlatAppearance.CheckedBackColor = System.Drawing.Color.Transparent;
            this.key16.FlatAppearance.MouseDownBackColor = System.Drawing.Color.Transparent;
            this.key16.FlatAppearance.MouseOverBackColor = System.Drawing.Color.Transparent;
            this.key16.FlatStyle = System.Windows.Forms.FlatStyle.System;
            this.key16.Font = new System.Drawing.Font("Tw Cen MT", 26.25F, System.Drawing.FontStyle.Bold);
            this.key16.ForeColor = System.Drawing.Color.Black;
            this.key16.ImeMode = System.Windows.Forms.ImeMode.NoControl;
            this.key16.Location = new System.Drawing.Point(422, 15);
            this.key16.Name = "key16";
            this.key16.Size = new System.Drawing.Size(38, 50);
            this.key16.TabIndex = 9;
            this.key16.Text = "A";
            this.key16.UseVisualStyleBackColor = false;
            this.key16.MouseClick += new System.Windows.Forms.MouseEventHandler(this.key13_MouseClick);
            // 
            // key17
            // 
            this.key17.Anchor = ((System.Windows.Forms.AnchorStyles)((System.Windows.Forms.AnchorStyles.Bottom | System.Windows.Forms.AnchorStyles.Right)));
            this.key17.BackColor = System.Drawing.Color.Transparent;
            this.key17.BackgroundImage = ((System.Drawing.Image)(resources.GetObject("key17.BackgroundImage")));
            this.key17.BackgroundImageLayout = System.Windows.Forms.ImageLayout.Zoom;
            this.key17.Cursor = System.Windows.Forms.Cursors.Hand;
            this.key17.FlatAppearance.BorderSize = 0;
            this.key17.FlatAppearance.CheckedBackColor = System.Drawing.Color.Transparent;
            this.key17.FlatAppearance.MouseDownBackColor = System.Drawing.Color.Transparent;
            this.key17.FlatAppearance.MouseOverBackColor = System.Drawing.Color.Transparent;
            this.key17.FlatStyle = System.Windows.Forms.FlatStyle.System;
            this.key17.Font = new System.Drawing.Font("Tw Cen MT", 26.25F, System.Drawing.FontStyle.Bold);
            this.key17.ForeColor = System.Drawing.Color.Black;
            this.key17.ImeMode = System.Windows.Forms.ImeMode.NoControl;
            this.key17.Location = new System.Drawing.Point(26, 15);
            this.key17.Name = "key17";
            this.key17.Size = new System.Drawing.Size(38, 50);
            this.key17.TabIndex = 0;
            this.key17.Text = "A";
            this.key17.UseVisualStyleBackColor = false;
            this.key17.MouseClick += new System.Windows.Forms.MouseEventHandler(this.key13_MouseClick);
            // 
            // key26
            // 
            this.key26.Anchor = ((System.Windows.Forms.AnchorStyles)((System.Windows.Forms.AnchorStyles.Bottom | System.Windows.Forms.AnchorStyles.Right)));
            this.key26.BackColor = System.Drawing.Color.Transparent;
            this.key26.BackgroundImage = ((System.Drawing.Image)(resources.GetObject("key26.BackgroundImage")));
            this.key26.BackgroundImageLayout = System.Windows.Forms.ImageLayout.Zoom;
            this.key26.Cursor = System.Windows.Forms.Cursors.Hand;
            this.key26.FlatAppearance.BorderSize = 0;
            this.key26.FlatAppearance.CheckedBackColor = System.Drawing.Color.Transparent;
            this.key26.FlatAppearance.MouseDownBackColor = System.Drawing.Color.Transparent;
            this.key26.FlatAppearance.MouseOverBackColor = System.Drawing.Color.Transparent;
            this.key26.FlatStyle = System.Windows.Forms.FlatStyle.System;
            this.key26.Font = new System.Drawing.Font("Tw Cen MT", 26.25F, System.Drawing.FontStyle.Bold);
            this.key26.ForeColor = System.Drawing.Color.Black;
            this.key26.ImeMode = System.Windows.Forms.ImeMode.NoControl;
            this.key26.Location = new System.Drawing.Point(81, 123);
            this.key26.Name = "key26";
            this.key26.Size = new System.Drawing.Size(38, 50);
            this.key26.TabIndex = 19;
            this.key26.Text = "A";
            this.key26.UseVisualStyleBackColor = false;
            this.key26.MouseClick += new System.Windows.Forms.MouseEventHandler(this.key13_MouseClick);
            // 
            // key18
            // 
            this.key18.Anchor = ((System.Windows.Forms.AnchorStyles)((System.Windows.Forms.AnchorStyles.Bottom | System.Windows.Forms.AnchorStyles.Right)));
            this.key18.BackColor = System.Drawing.Color.Transparent;
            this.key18.BackgroundImage = ((System.Drawing.Image)(resources.GetObject("key18.BackgroundImage")));
            this.key18.BackgroundImageLayout = System.Windows.Forms.ImageLayout.Zoom;
            this.key18.Cursor = System.Windows.Forms.Cursors.Hand;
            this.key18.FlatAppearance.BorderSize = 0;
            this.key18.FlatAppearance.CheckedBackColor = System.Drawing.Color.Transparent;
            this.key18.FlatAppearance.MouseDownBackColor = System.Drawing.Color.Transparent;
            this.key18.FlatAppearance.MouseOverBackColor = System.Drawing.Color.Transparent;
            this.key18.FlatStyle = System.Windows.Forms.FlatStyle.System;
            this.key18.Font = new System.Drawing.Font("Tw Cen MT", 26.25F, System.Drawing.FontStyle.Bold);
            this.key18.ForeColor = System.Drawing.Color.Black;
            this.key18.ImeMode = System.Windows.Forms.ImeMode.NoControl;
            this.key18.Location = new System.Drawing.Point(158, 15);
            this.key18.Name = "key18";
            this.key18.Size = new System.Drawing.Size(38, 50);
            this.key18.TabIndex = 3;
            this.key18.Text = "A";
            this.key18.UseVisualStyleBackColor = false;
            this.key18.MouseClick += new System.Windows.Forms.MouseEventHandler(this.key13_MouseClick);
            // 
            // key25
            // 
            this.key25.Anchor = ((System.Windows.Forms.AnchorStyles)((System.Windows.Forms.AnchorStyles.Bottom | System.Windows.Forms.AnchorStyles.Right)));
            this.key25.BackColor = System.Drawing.Color.Transparent;
            this.key25.BackgroundImage = ((System.Drawing.Image)(resources.GetObject("key25.BackgroundImage")));
            this.key25.BackgroundImageLayout = System.Windows.Forms.ImageLayout.Zoom;
            this.key25.Cursor = System.Windows.Forms.Cursors.Hand;
            this.key25.FlatAppearance.BorderSize = 0;
            this.key25.FlatAppearance.CheckedBackColor = System.Drawing.Color.Transparent;
            this.key25.FlatAppearance.MouseDownBackColor = System.Drawing.Color.Transparent;
            this.key25.FlatAppearance.MouseOverBackColor = System.Drawing.Color.Transparent;
            this.key25.FlatStyle = System.Windows.Forms.FlatStyle.System;
            this.key25.Font = new System.Drawing.Font("Tw Cen MT", 26.25F, System.Drawing.FontStyle.Bold);
            this.key25.ForeColor = System.Drawing.Color.Black;
            this.key25.ImeMode = System.Windows.Forms.ImeMode.NoControl;
            this.key25.Location = new System.Drawing.Point(246, 15);
            this.key25.Name = "key25";
            this.key25.Size = new System.Drawing.Size(38, 50);
            this.key25.TabIndex = 5;
            this.key25.Text = "A";
            this.key25.UseVisualStyleBackColor = false;
            this.key25.MouseClick += new System.Windows.Forms.MouseEventHandler(this.key13_MouseClick);
            // 
            // key19
            // 
            this.key19.Anchor = ((System.Windows.Forms.AnchorStyles)((System.Windows.Forms.AnchorStyles.Bottom | System.Windows.Forms.AnchorStyles.Right)));
            this.key19.BackColor = System.Drawing.Color.Transparent;
            this.key19.BackgroundImage = ((System.Drawing.Image)(resources.GetObject("key19.BackgroundImage")));
            this.key19.BackgroundImageLayout = System.Windows.Forms.ImageLayout.Zoom;
            this.key19.Cursor = System.Windows.Forms.Cursors.Hand;
            this.key19.FlatAppearance.BorderSize = 0;
            this.key19.FlatAppearance.CheckedBackColor = System.Drawing.Color.Transparent;
            this.key19.FlatAppearance.MouseDownBackColor = System.Drawing.Color.Transparent;
            this.key19.FlatAppearance.MouseOverBackColor = System.Drawing.Color.Transparent;
            this.key19.FlatStyle = System.Windows.Forms.FlatStyle.System;
            this.key19.Font = new System.Drawing.Font("Tw Cen MT", 26.25F, System.Drawing.FontStyle.Bold);
            this.key19.ForeColor = System.Drawing.Color.Black;
            this.key19.ImeMode = System.Windows.Forms.ImeMode.NoControl;
            this.key19.Location = new System.Drawing.Point(87, 69);
            this.key19.Name = "key19";
            this.key19.Size = new System.Drawing.Size(38, 50);
            this.key19.TabIndex = 11;
            this.key19.Text = "A";
            this.key19.UseVisualStyleBackColor = false;
            this.key19.MouseClick += new System.Windows.Forms.MouseEventHandler(this.key13_MouseClick);
            // 
            // key15
            // 
            this.key15.Anchor = ((System.Windows.Forms.AnchorStyles)((System.Windows.Forms.AnchorStyles.Bottom | System.Windows.Forms.AnchorStyles.Right)));
            this.key15.BackColor = System.Drawing.Color.Transparent;
            this.key15.BackgroundImage = ((System.Drawing.Image)(resources.GetObject("key15.BackgroundImage")));
            this.key15.BackgroundImageLayout = System.Windows.Forms.ImageLayout.Zoom;
            this.key15.Cursor = System.Windows.Forms.Cursors.Hand;
            this.key15.FlatAppearance.BorderSize = 0;
            this.key15.FlatAppearance.CheckedBackColor = System.Drawing.Color.Transparent;
            this.key15.FlatAppearance.MouseDownBackColor = System.Drawing.Color.Transparent;
            this.key15.FlatAppearance.MouseOverBackColor = System.Drawing.Color.Transparent;
            this.key15.FlatStyle = System.Windows.Forms.FlatStyle.System;
            this.key15.Font = new System.Drawing.Font("Tw Cen MT", 26.25F, System.Drawing.FontStyle.Bold);
            this.key15.ForeColor = System.Drawing.Color.Black;
            this.key15.ImeMode = System.Windows.Forms.ImeMode.NoControl;
            this.key15.Location = new System.Drawing.Point(378, 15);
            this.key15.Name = "key15";
            this.key15.Size = new System.Drawing.Size(38, 50);
            this.key15.TabIndex = 8;
            this.key15.Text = "A";
            this.key15.UseVisualStyleBackColor = false;
            this.key15.MouseClick += new System.Windows.Forms.MouseEventHandler(this.key13_MouseClick);
            // 
            // key20
            // 
            this.key20.Anchor = ((System.Windows.Forms.AnchorStyles)((System.Windows.Forms.AnchorStyles.Bottom | System.Windows.Forms.AnchorStyles.Right)));
            this.key20.BackColor = System.Drawing.Color.Transparent;
            this.key20.BackgroundImage = ((System.Drawing.Image)(resources.GetObject("key20.BackgroundImage")));
            this.key20.BackgroundImageLayout = System.Windows.Forms.ImageLayout.Zoom;
            this.key20.Cursor = System.Windows.Forms.Cursors.Hand;
            this.key20.FlatAppearance.BorderSize = 0;
            this.key20.FlatAppearance.CheckedBackColor = System.Drawing.Color.Transparent;
            this.key20.FlatAppearance.MouseDownBackColor = System.Drawing.Color.Transparent;
            this.key20.FlatAppearance.MouseOverBackColor = System.Drawing.Color.Transparent;
            this.key20.FlatStyle = System.Windows.Forms.FlatStyle.System;
            this.key20.Font = new System.Drawing.Font("Tw Cen MT", 26.25F, System.Drawing.FontStyle.Bold);
            this.key20.ForeColor = System.Drawing.Color.Black;
            this.key20.ImeMode = System.Windows.Forms.ImeMode.NoControl;
            this.key20.Location = new System.Drawing.Point(202, 15);
            this.key20.Name = "key20";
            this.key20.Size = new System.Drawing.Size(38, 50);
            this.key20.TabIndex = 4;
            this.key20.Text = "A";
            this.key20.UseVisualStyleBackColor = false;
            this.key20.MouseClick += new System.Windows.Forms.MouseEventHandler(this.key13_MouseClick);
            // 
            // key14
            // 
            this.key14.Anchor = ((System.Windows.Forms.AnchorStyles)((System.Windows.Forms.AnchorStyles.Bottom | System.Windows.Forms.AnchorStyles.Right)));
            this.key14.BackColor = System.Drawing.Color.Transparent;
            this.key14.BackgroundImage = ((System.Drawing.Image)(resources.GetObject("key14.BackgroundImage")));
            this.key14.BackgroundImageLayout = System.Windows.Forms.ImageLayout.Zoom;
            this.key14.Cursor = System.Windows.Forms.Cursors.Hand;
            this.key14.FlatAppearance.BorderSize = 0;
            this.key14.FlatAppearance.CheckedBackColor = System.Drawing.Color.Transparent;
            this.key14.FlatAppearance.MouseDownBackColor = System.Drawing.Color.Transparent;
            this.key14.FlatAppearance.MouseOverBackColor = System.Drawing.Color.Transparent;
            this.key14.FlatStyle = System.Windows.Forms.FlatStyle.System;
            this.key14.Font = new System.Drawing.Font("Tw Cen MT", 26.25F, System.Drawing.FontStyle.Bold);
            this.key14.ForeColor = System.Drawing.Color.Black;
            this.key14.ImeMode = System.Windows.Forms.ImeMode.NoControl;
            this.key14.Location = new System.Drawing.Point(311, 123);
            this.key14.Name = "key14";
            this.key14.Size = new System.Drawing.Size(38, 50);
            this.key14.TabIndex = 24;
            this.key14.Text = "A";
            this.key14.UseVisualStyleBackColor = false;
            this.key14.MouseClick += new System.Windows.Forms.MouseEventHandler(this.key13_MouseClick);
            // 
            // key21
            // 
            this.key21.Anchor = ((System.Windows.Forms.AnchorStyles)((System.Windows.Forms.AnchorStyles.Bottom | System.Windows.Forms.AnchorStyles.Right)));
            this.key21.BackColor = System.Drawing.Color.Transparent;
            this.key21.BackgroundImage = ((System.Drawing.Image)(resources.GetObject("key21.BackgroundImage")));
            this.key21.BackgroundImageLayout = System.Windows.Forms.ImageLayout.Zoom;
            this.key21.Cursor = System.Windows.Forms.Cursors.Hand;
            this.key21.FlatAppearance.BorderSize = 0;
            this.key21.FlatAppearance.CheckedBackColor = System.Drawing.Color.Transparent;
            this.key21.FlatAppearance.MouseDownBackColor = System.Drawing.Color.Transparent;
            this.key21.FlatAppearance.MouseOverBackColor = System.Drawing.Color.Transparent;
            this.key21.FlatStyle = System.Windows.Forms.FlatStyle.System;
            this.key21.Font = new System.Drawing.Font("Tw Cen MT", 26.25F, System.Drawing.FontStyle.Bold);
            this.key21.ForeColor = System.Drawing.Color.Black;
            this.key21.ImeMode = System.Windows.Forms.ImeMode.NoControl;
            this.key21.Location = new System.Drawing.Point(290, 15);
            this.key21.Name = "key21";
            this.key21.Size = new System.Drawing.Size(38, 50);
            this.key21.TabIndex = 6;
            this.key21.Text = "A";
            this.key21.UseVisualStyleBackColor = false;
            this.key21.MouseClick += new System.Windows.Forms.MouseEventHandler(this.key13_MouseClick);
            // 
            // key22
            // 
            this.key22.Anchor = ((System.Windows.Forms.AnchorStyles)((System.Windows.Forms.AnchorStyles.Bottom | System.Windows.Forms.AnchorStyles.Right)));
            this.key22.BackColor = System.Drawing.Color.Transparent;
            this.key22.BackgroundImage = ((System.Drawing.Image)(resources.GetObject("key22.BackgroundImage")));
            this.key22.BackgroundImageLayout = System.Windows.Forms.ImageLayout.Zoom;
            this.key22.Cursor = System.Windows.Forms.Cursors.Hand;
            this.key22.FlatAppearance.BorderSize = 0;
            this.key22.FlatAppearance.CheckedBackColor = System.Drawing.Color.Transparent;
            this.key22.FlatAppearance.MouseDownBackColor = System.Drawing.Color.Transparent;
            this.key22.FlatAppearance.MouseOverBackColor = System.Drawing.Color.Transparent;
            this.key22.FlatStyle = System.Windows.Forms.FlatStyle.System;
            this.key22.Font = new System.Drawing.Font("Tw Cen MT", 26.25F, System.Drawing.FontStyle.Bold);
            this.key22.ForeColor = System.Drawing.Color.Black;
            this.key22.ImeMode = System.Windows.Forms.ImeMode.NoControl;
            this.key22.Location = new System.Drawing.Point(219, 123);
            this.key22.Name = "key22";
            this.key22.Size = new System.Drawing.Size(38, 50);
            this.key22.TabIndex = 22;
            this.key22.Text = "A";
            this.key22.UseVisualStyleBackColor = false;
            this.key22.MouseClick += new System.Windows.Forms.MouseEventHandler(this.key13_MouseClick);
            // 
            // key12
            // 
            this.key12.Anchor = ((System.Windows.Forms.AnchorStyles)((System.Windows.Forms.AnchorStyles.Bottom | System.Windows.Forms.AnchorStyles.Right)));
            this.key12.BackColor = System.Drawing.Color.Transparent;
            this.key12.BackgroundImage = ((System.Drawing.Image)(resources.GetObject("key12.BackgroundImage")));
            this.key12.BackgroundImageLayout = System.Windows.Forms.ImageLayout.Zoom;
            this.key12.Cursor = System.Windows.Forms.Cursors.Hand;
            this.key12.FlatAppearance.BorderSize = 0;
            this.key12.FlatAppearance.CheckedBackColor = System.Drawing.Color.Transparent;
            this.key12.FlatAppearance.MouseDownBackColor = System.Drawing.Color.Transparent;
            this.key12.FlatAppearance.MouseOverBackColor = System.Drawing.Color.Transparent;
            this.key12.FlatStyle = System.Windows.Forms.FlatStyle.System;
            this.key12.Font = new System.Drawing.Font("Tw Cen MT", 26.25F, System.Drawing.FontStyle.Bold);
            this.key12.ForeColor = System.Drawing.Color.Black;
            this.key12.ImeMode = System.Windows.Forms.ImeMode.NoControl;
            this.key12.Location = new System.Drawing.Point(395, 69);
            this.key12.Name = "key12";
            this.key12.Size = new System.Drawing.Size(38, 50);
            this.key12.TabIndex = 18;
            this.key12.Text = "A";
            this.key12.UseVisualStyleBackColor = false;
            this.key12.MouseClick += new System.Windows.Forms.MouseEventHandler(this.key13_MouseClick);
            // 
            // key11
            // 
            this.key11.Anchor = ((System.Windows.Forms.AnchorStyles)((System.Windows.Forms.AnchorStyles.Bottom | System.Windows.Forms.AnchorStyles.Right)));
            this.key11.BackColor = System.Drawing.Color.Transparent;
            this.key11.BackgroundImage = ((System.Drawing.Image)(resources.GetObject("key11.BackgroundImage")));
            this.key11.BackgroundImageLayout = System.Windows.Forms.ImageLayout.Zoom;
            this.key11.Cursor = System.Windows.Forms.Cursors.Hand;
            this.key11.FlatAppearance.BorderSize = 0;
            this.key11.FlatAppearance.CheckedBackColor = System.Drawing.Color.Transparent;
            this.key11.FlatAppearance.MouseDownBackColor = System.Drawing.Color.Transparent;
            this.key11.FlatAppearance.MouseOverBackColor = System.Drawing.Color.Transparent;
            this.key11.FlatStyle = System.Windows.Forms.FlatStyle.System;
            this.key11.Font = new System.Drawing.Font("Tw Cen MT", 26.25F, System.Drawing.FontStyle.Bold);
            this.key11.ForeColor = System.Drawing.Color.Black;
            this.key11.ImeMode = System.Windows.Forms.ImeMode.NoControl;
            this.key11.Location = new System.Drawing.Point(351, 69);
            this.key11.Name = "key11";
            this.key11.Size = new System.Drawing.Size(38, 50);
            this.key11.TabIndex = 17;
            this.key11.Text = "A";
            this.key11.UseVisualStyleBackColor = false;
            this.key11.MouseClick += new System.Windows.Forms.MouseEventHandler(this.key13_MouseClick);
            // 
            // key24
            // 
            this.key24.Anchor = ((System.Windows.Forms.AnchorStyles)((System.Windows.Forms.AnchorStyles.Bottom | System.Windows.Forms.AnchorStyles.Right)));
            this.key24.BackColor = System.Drawing.Color.Transparent;
            this.key24.BackgroundImage = ((System.Drawing.Image)(resources.GetObject("key24.BackgroundImage")));
            this.key24.BackgroundImageLayout = System.Windows.Forms.ImageLayout.Zoom;
            this.key24.Cursor = System.Windows.Forms.Cursors.Hand;
            this.key24.FlatAppearance.BorderSize = 0;
            this.key24.FlatAppearance.CheckedBackColor = System.Drawing.Color.Transparent;
            this.key24.FlatAppearance.MouseDownBackColor = System.Drawing.Color.Transparent;
            this.key24.FlatAppearance.MouseOverBackColor = System.Drawing.Color.Transparent;
            this.key24.FlatStyle = System.Windows.Forms.FlatStyle.System;
            this.key24.Font = new System.Drawing.Font("Tw Cen MT", 26.25F, System.Drawing.FontStyle.Bold);
            this.key24.ForeColor = System.Drawing.Color.Black;
            this.key24.ImeMode = System.Windows.Forms.ImeMode.NoControl;
            this.key24.Location = new System.Drawing.Point(127, 123);
            this.key24.Name = "key24";
            this.key24.Size = new System.Drawing.Size(38, 50);
            this.key24.TabIndex = 20;
            this.key24.Text = "A";
            this.key24.UseVisualStyleBackColor = false;
            this.key24.MouseClick += new System.Windows.Forms.MouseEventHandler(this.key13_MouseClick);
            // 
            // key10
            // 
            this.key10.Anchor = ((System.Windows.Forms.AnchorStyles)((System.Windows.Forms.AnchorStyles.Bottom | System.Windows.Forms.AnchorStyles.Right)));
            this.key10.BackColor = System.Drawing.Color.Transparent;
            this.key10.BackgroundImage = ((System.Drawing.Image)(resources.GetObject("key10.BackgroundImage")));
            this.key10.BackgroundImageLayout = System.Windows.Forms.ImageLayout.Zoom;
            this.key10.Cursor = System.Windows.Forms.Cursors.Hand;
            this.key10.FlatAppearance.BorderSize = 0;
            this.key10.FlatAppearance.CheckedBackColor = System.Drawing.Color.Transparent;
            this.key10.FlatAppearance.MouseDownBackColor = System.Drawing.Color.Transparent;
            this.key10.FlatAppearance.MouseOverBackColor = System.Drawing.Color.Transparent;
            this.key10.FlatStyle = System.Windows.Forms.FlatStyle.System;
            this.key10.Font = new System.Drawing.Font("Tw Cen MT", 26.25F, System.Drawing.FontStyle.Bold);
            this.key10.ForeColor = System.Drawing.Color.Black;
            this.key10.ImeMode = System.Windows.Forms.ImeMode.NoControl;
            this.key10.Location = new System.Drawing.Point(307, 69);
            this.key10.Name = "key10";
            this.key10.Size = new System.Drawing.Size(38, 50);
            this.key10.TabIndex = 16;
            this.key10.Text = "A";
            this.key10.UseVisualStyleBackColor = false;
            this.key10.MouseClick += new System.Windows.Forms.MouseEventHandler(this.key13_MouseClick);
            // 
            // key9
            // 
            this.key9.Anchor = ((System.Windows.Forms.AnchorStyles)((System.Windows.Forms.AnchorStyles.Bottom | System.Windows.Forms.AnchorStyles.Right)));
            this.key9.BackColor = System.Drawing.Color.Transparent;
            this.key9.BackgroundImage = ((System.Drawing.Image)(resources.GetObject("key9.BackgroundImage")));
            this.key9.BackgroundImageLayout = System.Windows.Forms.ImageLayout.Zoom;
            this.key9.Cursor = System.Windows.Forms.Cursors.Hand;
            this.key9.FlatAppearance.BorderSize = 0;
            this.key9.FlatAppearance.CheckedBackColor = System.Drawing.Color.Transparent;
            this.key9.FlatAppearance.MouseDownBackColor = System.Drawing.Color.Transparent;
            this.key9.FlatAppearance.MouseOverBackColor = System.Drawing.Color.Transparent;
            this.key9.FlatStyle = System.Windows.Forms.FlatStyle.System;
            this.key9.Font = new System.Drawing.Font("Tw Cen MT", 26.25F, System.Drawing.FontStyle.Bold);
            this.key9.ForeColor = System.Drawing.Color.Black;
            this.key9.ImeMode = System.Windows.Forms.ImeMode.NoControl;
            this.key9.Location = new System.Drawing.Point(334, 15);
            this.key9.Name = "key9";
            this.key9.Size = new System.Drawing.Size(38, 50);
            this.key9.TabIndex = 7;
            this.key9.Text = "A";
            this.key9.UseVisualStyleBackColor = false;
            this.key9.MouseClick += new System.Windows.Forms.MouseEventHandler(this.key13_MouseClick);
            // 
            // key8
            // 
            this.key8.Anchor = ((System.Windows.Forms.AnchorStyles)((System.Windows.Forms.AnchorStyles.Bottom | System.Windows.Forms.AnchorStyles.Right)));
            this.key8.BackColor = System.Drawing.Color.Transparent;
            this.key8.BackgroundImage = ((System.Drawing.Image)(resources.GetObject("key8.BackgroundImage")));
            this.key8.BackgroundImageLayout = System.Windows.Forms.ImageLayout.Zoom;
            this.key8.Cursor = System.Windows.Forms.Cursors.Hand;
            this.key8.FlatAppearance.BorderSize = 0;
            this.key8.FlatAppearance.CheckedBackColor = System.Drawing.Color.Transparent;
            this.key8.FlatAppearance.MouseDownBackColor = System.Drawing.Color.Transparent;
            this.key8.FlatAppearance.MouseOverBackColor = System.Drawing.Color.Transparent;
            this.key8.FlatStyle = System.Windows.Forms.FlatStyle.System;
            this.key8.Font = new System.Drawing.Font("Tw Cen MT", 26.25F, System.Drawing.FontStyle.Bold);
            this.key8.ForeColor = System.Drawing.Color.Black;
            this.key8.ImeMode = System.Windows.Forms.ImeMode.NoControl;
            this.key8.Location = new System.Drawing.Point(263, 69);
            this.key8.Name = "key8";
            this.key8.Size = new System.Drawing.Size(38, 50);
            this.key8.TabIndex = 15;
            this.key8.Text = "A";
            this.key8.UseVisualStyleBackColor = false;
            this.key8.MouseClick += new System.Windows.Forms.MouseEventHandler(this.key13_MouseClick);
            // 
            // key7
            // 
            this.key7.Anchor = ((System.Windows.Forms.AnchorStyles)((System.Windows.Forms.AnchorStyles.Bottom | System.Windows.Forms.AnchorStyles.Right)));
            this.key7.BackColor = System.Drawing.Color.Transparent;
            this.key7.BackgroundImage = ((System.Drawing.Image)(resources.GetObject("key7.BackgroundImage")));
            this.key7.BackgroundImageLayout = System.Windows.Forms.ImageLayout.Zoom;
            this.key7.Cursor = System.Windows.Forms.Cursors.Hand;
            this.key7.FlatAppearance.BorderColor = System.Drawing.Color.FromArgb(((int)(((byte)(192)))), ((int)(((byte)(64)))), ((int)(((byte)(0)))));
            this.key7.FlatAppearance.BorderSize = 0;
            this.key7.FlatAppearance.CheckedBackColor = System.Drawing.Color.Transparent;
            this.key7.FlatAppearance.MouseDownBackColor = System.Drawing.Color.Transparent;
            this.key7.FlatAppearance.MouseOverBackColor = System.Drawing.Color.Transparent;
            this.key7.FlatStyle = System.Windows.Forms.FlatStyle.System;
            this.key7.Font = new System.Drawing.Font("Tw Cen MT", 26.25F, System.Drawing.FontStyle.Bold);
            this.key7.ForeColor = System.Drawing.Color.Black;
            this.key7.ImeMode = System.Windows.Forms.ImeMode.NoControl;
            this.key7.Location = new System.Drawing.Point(219, 69);
            this.key7.Name = "key7";
            this.key7.Size = new System.Drawing.Size(38, 50);
            this.key7.TabIndex = 14;
            this.key7.Text = "A";
            this.key7.UseVisualStyleBackColor = false;
            this.key7.MouseClick += new System.Windows.Forms.MouseEventHandler(this.key13_MouseClick);
            // 
            // key6
            // 
            this.key6.Anchor = ((System.Windows.Forms.AnchorStyles)((System.Windows.Forms.AnchorStyles.Bottom | System.Windows.Forms.AnchorStyles.Right)));
            this.key6.BackColor = System.Drawing.Color.Transparent;
            this.key6.BackgroundImage = ((System.Drawing.Image)(resources.GetObject("key6.BackgroundImage")));
            this.key6.BackgroundImageLayout = System.Windows.Forms.ImageLayout.Zoom;
            this.key6.Cursor = System.Windows.Forms.Cursors.Hand;
            this.key6.FlatAppearance.BorderSize = 0;
            this.key6.FlatAppearance.CheckedBackColor = System.Drawing.Color.Transparent;
            this.key6.FlatAppearance.MouseDownBackColor = System.Drawing.Color.Transparent;
            this.key6.FlatAppearance.MouseOverBackColor = System.Drawing.Color.Transparent;
            this.key6.FlatStyle = System.Windows.Forms.FlatStyle.System;
            this.key6.Font = new System.Drawing.Font("Tw Cen MT", 26.25F, System.Drawing.FontStyle.Bold);
            this.key6.ForeColor = System.Drawing.Color.Black;
            this.key6.ImeMode = System.Windows.Forms.ImeMode.NoControl;
            this.key6.Location = new System.Drawing.Point(175, 69);
            this.key6.Name = "key6";
            this.key6.Size = new System.Drawing.Size(38, 50);
            this.key6.TabIndex = 13;
            this.key6.Text = "A";
            this.key6.UseVisualStyleBackColor = false;
            this.key6.MouseClick += new System.Windows.Forms.MouseEventHandler(this.key13_MouseClick);
            // 
            // key5
            // 
            this.key5.Anchor = ((System.Windows.Forms.AnchorStyles)((System.Windows.Forms.AnchorStyles.Bottom | System.Windows.Forms.AnchorStyles.Right)));
            this.key5.BackColor = System.Drawing.Color.Transparent;
            this.key5.BackgroundImage = ((System.Drawing.Image)(resources.GetObject("key5.BackgroundImage")));
            this.key5.BackgroundImageLayout = System.Windows.Forms.ImageLayout.Zoom;
            this.key5.Cursor = System.Windows.Forms.Cursors.Hand;
            this.key5.FlatAppearance.BorderSize = 0;
            this.key5.FlatAppearance.CheckedBackColor = System.Drawing.Color.Transparent;
            this.key5.FlatAppearance.MouseDownBackColor = System.Drawing.Color.Transparent;
            this.key5.FlatAppearance.MouseOverBackColor = System.Drawing.Color.Transparent;
            this.key5.FlatStyle = System.Windows.Forms.FlatStyle.System;
            this.key5.Font = new System.Drawing.Font("Tw Cen MT", 26.25F, System.Drawing.FontStyle.Bold);
            this.key5.ForeColor = System.Drawing.Color.Black;
            this.key5.ImeMode = System.Windows.Forms.ImeMode.NoControl;
            this.key5.Location = new System.Drawing.Point(114, 15);
            this.key5.Name = "key5";
            this.key5.Size = new System.Drawing.Size(38, 50);
            this.key5.TabIndex = 2;
            this.key5.Text = "A";
            this.key5.UseVisualStyleBackColor = false;
            this.key5.MouseClick += new System.Windows.Forms.MouseEventHandler(this.key13_MouseClick);
            // 
            // key4
            // 
            this.key4.Anchor = ((System.Windows.Forms.AnchorStyles)((System.Windows.Forms.AnchorStyles.Bottom | System.Windows.Forms.AnchorStyles.Right)));
            this.key4.BackColor = System.Drawing.Color.Transparent;
            this.key4.BackgroundImage = ((System.Drawing.Image)(resources.GetObject("key4.BackgroundImage")));
            this.key4.BackgroundImageLayout = System.Windows.Forms.ImageLayout.Zoom;
            this.key4.Cursor = System.Windows.Forms.Cursors.Hand;
            this.key4.FlatAppearance.BorderSize = 0;
            this.key4.FlatAppearance.CheckedBackColor = System.Drawing.Color.Transparent;
            this.key4.FlatAppearance.MouseDownBackColor = System.Drawing.Color.Transparent;
            this.key4.FlatAppearance.MouseOverBackColor = System.Drawing.Color.Transparent;
            this.key4.FlatStyle = System.Windows.Forms.FlatStyle.System;
            this.key4.Font = new System.Drawing.Font("Tw Cen MT", 26.25F, System.Drawing.FontStyle.Bold);
            this.key4.ForeColor = System.Drawing.Color.Black;
            this.key4.ImeMode = System.Windows.Forms.ImeMode.NoControl;
            this.key4.Location = new System.Drawing.Point(131, 69);
            this.key4.Name = "key4";
            this.key4.Size = new System.Drawing.Size(38, 50);
            this.key4.TabIndex = 12;
            this.key4.Text = "A";
            this.key4.UseVisualStyleBackColor = false;
            this.key4.MouseClick += new System.Windows.Forms.MouseEventHandler(this.key13_MouseClick);
            // 
            // key3
            // 
            this.key3.Anchor = ((System.Windows.Forms.AnchorStyles)((System.Windows.Forms.AnchorStyles.Bottom | System.Windows.Forms.AnchorStyles.Right)));
            this.key3.BackColor = System.Drawing.Color.Transparent;
            this.key3.BackgroundImage = ((System.Drawing.Image)(resources.GetObject("key3.BackgroundImage")));
            this.key3.BackgroundImageLayout = System.Windows.Forms.ImageLayout.Zoom;
            this.key3.Cursor = System.Windows.Forms.Cursors.Hand;
            this.key3.FlatAppearance.BorderSize = 0;
            this.key3.FlatAppearance.CheckedBackColor = System.Drawing.Color.Transparent;
            this.key3.FlatAppearance.MouseDownBackColor = System.Drawing.Color.Transparent;
            this.key3.FlatAppearance.MouseOverBackColor = System.Drawing.Color.Transparent;
            this.key3.FlatStyle = System.Windows.Forms.FlatStyle.System;
            this.key3.Font = new System.Drawing.Font("Tw Cen MT", 26.25F, System.Drawing.FontStyle.Bold);
            this.key3.ForeColor = System.Drawing.Color.Black;
            this.key3.ImeMode = System.Windows.Forms.ImeMode.NoControl;
            this.key3.Location = new System.Drawing.Point(173, 123);
            this.key3.Name = "key3";
            this.key3.Size = new System.Drawing.Size(38, 50);
            this.key3.TabIndex = 21;
            this.key3.Text = "A";
            this.key3.UseVisualStyleBackColor = false;
            this.key3.MouseClick += new System.Windows.Forms.MouseEventHandler(this.key13_MouseClick);
            // 
            // key2
            // 
            this.key2.Anchor = ((System.Windows.Forms.AnchorStyles)((System.Windows.Forms.AnchorStyles.Bottom | System.Windows.Forms.AnchorStyles.Right)));
            this.key2.BackColor = System.Drawing.Color.Transparent;
            this.key2.BackgroundImage = ((System.Drawing.Image)(resources.GetObject("key2.BackgroundImage")));
            this.key2.BackgroundImageLayout = System.Windows.Forms.ImageLayout.Zoom;
            this.key2.Cursor = System.Windows.Forms.Cursors.Hand;
            this.key2.FlatAppearance.BorderSize = 0;
            this.key2.FlatAppearance.CheckedBackColor = System.Drawing.Color.Transparent;
            this.key2.FlatAppearance.MouseDownBackColor = System.Drawing.Color.Transparent;
            this.key2.FlatAppearance.MouseOverBackColor = System.Drawing.Color.Transparent;
            this.key2.FlatStyle = System.Windows.Forms.FlatStyle.System;
            this.key2.Font = new System.Drawing.Font("Tw Cen MT", 26.25F, System.Drawing.FontStyle.Bold);
            this.key2.ForeColor = System.Drawing.Color.Black;
            this.key2.ImeMode = System.Windows.Forms.ImeMode.NoControl;
            this.key2.Location = new System.Drawing.Point(265, 123);
            this.key2.Name = "key2";
            this.key2.Size = new System.Drawing.Size(38, 50);
            this.key2.TabIndex = 23;
            this.key2.Text = "A";
            this.key2.UseVisualStyleBackColor = false;
            this.key2.MouseClick += new System.Windows.Forms.MouseEventHandler(this.key13_MouseClick);
            // 
            // key1
            // 
            this.key1.Anchor = ((System.Windows.Forms.AnchorStyles)((System.Windows.Forms.AnchorStyles.Bottom | System.Windows.Forms.AnchorStyles.Right)));
            this.key1.BackColor = System.Drawing.Color.Transparent;
            this.key1.BackgroundImage = ((System.Drawing.Image)(resources.GetObject("key1.BackgroundImage")));
            this.key1.BackgroundImageLayout = System.Windows.Forms.ImageLayout.Zoom;
            this.key1.Cursor = System.Windows.Forms.Cursors.Hand;
            this.key1.FlatAppearance.BorderSize = 0;
            this.key1.FlatAppearance.CheckedBackColor = System.Drawing.Color.Transparent;
            this.key1.FlatAppearance.MouseDownBackColor = System.Drawing.Color.Transparent;
            this.key1.FlatAppearance.MouseOverBackColor = System.Drawing.Color.Transparent;
            this.key1.FlatStyle = System.Windows.Forms.FlatStyle.System;
            this.key1.Font = new System.Drawing.Font("Tw Cen MT", 26.25F, System.Drawing.FontStyle.Bold);
            this.key1.ForeColor = System.Drawing.Color.Black;
            this.key1.ImeMode = System.Windows.Forms.ImeMode.NoControl;
            this.key1.Location = new System.Drawing.Point(43, 69);
            this.key1.Name = "key1";
            this.key1.Size = new System.Drawing.Size(38, 50);
            this.key1.TabIndex = 10;
            this.key1.Text = "A";
            this.key1.UseVisualStyleBackColor = false;
            this.key1.MouseClick += new System.Windows.Forms.MouseEventHandler(this.key13_MouseClick);
            // 
            // Keyboard
            // 
            this.BackColor = System.Drawing.Color.Transparent;
            this.BackgroundImage = global::GuessPakGanern.Properties.Resources.keyboard_bg;
            this.BackgroundImageLayout = System.Windows.Forms.ImageLayout.Stretch;
            this.Controls.Add(this.key23);
            this.Controls.Add(this.key13);
            this.Controls.Add(this.key16);
            this.Controls.Add(this.key17);
            this.Controls.Add(this.key26);
            this.Controls.Add(this.key18);
            this.Controls.Add(this.key25);
            this.Controls.Add(this.key19);
            this.Controls.Add(this.key15);
            this.Controls.Add(this.key20);
            this.Controls.Add(this.key14);
            this.Controls.Add(this.key21);
            this.Controls.Add(this.key22);
            this.Controls.Add(this.key12);
            this.Controls.Add(this.key11);
            this.Controls.Add(this.key24);
            this.Controls.Add(this.key10);
            this.Controls.Add(this.key9);
            this.Controls.Add(this.key8);
            this.Controls.Add(this.key7);
            this.Controls.Add(this.key6);
            this.Controls.Add(this.key5);
            this.Controls.Add(this.key4);
            this.Controls.Add(this.key3);
            this.Controls.Add(this.key2);
            this.Controls.Add(this.key1);
            this.Name = "Keyboard";
            this.Size = new System.Drawing.Size(486, 188);
            this.Load += new System.EventHandler(this.Keyboard_Load);
            this.ResumeLayout(false);

        }

        #endregion

        public Key key1;
        public Key key2;
        public Key key3;
        public Key key4;
        public Key key5;
        public Key key6;
        public Key key7;
        public Key key8;
        public Key key9;
        public Key key10;
        public Key key16;
        public Key key17;
        public Key key18;
        public Key key19;
        public Key key20;
        public Key key21;
        public Key key22;
        public Key key24;
        public Key key11;
        public Key key12;
        public Key key14;
        public Key key15;
        public Key key25;
        public Key key26;
        public Key key13;
        public Key key23;
    }
}
