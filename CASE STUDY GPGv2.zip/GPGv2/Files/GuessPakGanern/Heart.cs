﻿using System.ComponentModel;
using System.Windows.Forms;

namespace GuessPakGanern
{
    public partial class Heart : PictureBox
    {
        public Heart()
        {
            InitializeComponent();
        }

        public Heart(IContainer container)
        {
            InitializeComponent();
        }
    }
}
