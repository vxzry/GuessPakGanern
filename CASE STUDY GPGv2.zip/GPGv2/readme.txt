Members: 

Golosinda, Amiel Valerie G.
Subiera, Xandra Faye F.

BSIT 3-1D